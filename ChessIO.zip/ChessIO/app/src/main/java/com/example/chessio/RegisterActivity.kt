package com.example.chessio

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val userLogin: EditText = findViewById(R.id.login_reg)
        val userName: EditText = findViewById(R.id.name_reg)
        val userAddress: EditText = findViewById(R.id.adress_reg)
        val userPassword: EditText = findViewById(R.id.password_reg)
        val userPasswordAgain: EditText = findViewById(R.id.password_again_reg)

        val buttonBack: Button = findViewById(R.id.button_back)
        val buttonReg: Button = findViewById(R.id.button_reg)

        buttonReg.setOnClickListener {
            val login = userLogin.text.toString().trim()
            val name = userName.text.toString().trim()
            val address = userAddress.text.toString().trim()
            val password = userPassword.text.toString().trim()
            val passwordAgain = userPasswordAgain.text.toString().trim()

            if (login.isEmpty() || name.isEmpty() || address.isEmpty() || password.isEmpty() || passwordAgain.isEmpty()) {
                Toast.makeText(this, "Не все поля заполнены", Toast.LENGTH_LONG).show()
            } else {
                if (password != passwordAgain) {
                    Toast.makeText(this, "Введённые пароли не совпадают", Toast.LENGTH_LONG).show()
                } else {
                    val user = User(login, name, address, password)

                    // Отправка данных на сервер
                    RetrofitClient.apiService.registerUser (user).enqueue(object : Callback<User> {
                        override fun onResponse(call: Call<User>, response: Response<User>) {
                            if (response.isSuccessful) {
                                userLogin.text.clear()
                                userName.text.clear()
                                userAddress.text.clear()
                                userPassword.text.clear()
                                userPasswordAgain.text.clear()

                                // Переход в MainActivity при успешной регистрации
                                val intent = Intent(this@RegisterActivity, MainActivity::class.java)
                                startActivity(intent)
                                finish() // Закрыть текущую активность, если это необходимо
                            } else {
                                // Обработка ошибок, если логин уже существует
                                if (response.code() == 400) {
                                    Toast.makeText(
                                        this@RegisterActivity,
                                        "Ошибка: Пользователь с таким логином уже существует",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        this@RegisterActivity,
                                        "Ошибка: ${response.message()}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        }

                        override fun onFailure(call: Call<User>, t: Throwable) {
                            Toast.makeText(this@RegisterActivity, "Ошибка сети: ${t.message}", Toast.LENGTH_LONG).show()
                        }
                    })
                }
            }
        }

        buttonBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}