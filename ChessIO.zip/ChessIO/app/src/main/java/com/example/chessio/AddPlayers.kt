package com.example.chessio

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddPlayers : AppCompatActivity() {
    private var tournamentId: Int = 0 // Переменная для хранения ID турнира
    private lateinit var recyclerView: RecyclerView
    private lateinit var playerAdapter: PlayerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_players)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Инициализация RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        playerAdapter = PlayerAdapter(emptyList()) // Пустой список на начальном этапе
        recyclerView.adapter = playerAdapter

        // Получаем tournamentId из Intent
        tournamentId = intent.getIntExtra("TOURNAMENT_ID", 0)

        // Получаем список игроков
        getPlayers()

        val buttonBack: Button = findViewById(R.id.button_back)
        val buttonAccept: Button = findViewById(R.id.button_accept)
        val buttonAddPlayer: Button = findViewById(R.id.button_add_player)

        buttonAccept.setOnClickListener {
            val intent = Intent(this, TournamentCreate::class.java)
            startActivity(intent)
        }

        buttonAddPlayer.setOnClickListener {
            val intent = Intent(this, AddPlayerOne::class.java)
            intent.putExtra("TOURNAMENT_ID", tournamentId) // Передаем tournamentId в AddPlayerOne
            startActivity(intent)
        }

        buttonBack.setOnClickListener {
            val intent = Intent(this, TournamentCreate::class.java)
            startActivity(intent)
        }
    }

    private fun getPlayers() {
        RetrofitClient.apiService.getPlayersByTournamentId(tournamentId).enqueue(object : Callback<List<Player>> {
            override fun onResponse(call: Call<List<Player>>, response: Response<List<Player>>) {
                if (response.isSuccessful) {
                    response.body()?.let { players ->
                        playerAdapter.updatePlayers(players) // Обновляем адаптер с новыми данными
                    }
                } else {
                    Toast.makeText(this@AddPlayers, "Ошибка: ${response.message()}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<List<Player>>, t: Throwable) {
                Toast.makeText(this@AddPlayers, "Ошибка сети: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }
}
