package com.example.chessio

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("login") val login: String,
    @SerializedName("username") val username: String,
    @SerializedName("address") val address: String,
    @SerializedName("password") val password: String
)