package com.example.chessio

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val buttonCreateTournament: Button = findViewById(R.id.button_create_tournam)
        val buttonInfo: Button = findViewById(R.id.button_info)
        val buttonProfile: Button = findViewById(R.id.button_profile)
        val buttonBack: Button = findViewById(R.id.button_back)

        buttonCreateTournament.setOnClickListener {
            val intent = Intent(this, TournamentCreate::class.java)
            startActivity(intent)
        }

        buttonInfo.setOnClickListener {
            val intent = Intent(this, InformationStand::class.java)
            startActivity(intent)
        }

        buttonProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        buttonBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}