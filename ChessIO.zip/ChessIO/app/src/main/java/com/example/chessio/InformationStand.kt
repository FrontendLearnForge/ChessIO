package com.example.chessio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.github.barteksc.pdfviewer.PDFView
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class InformationStand : AppCompatActivity() {

    private lateinit var pdfView: PDFView
    private lateinit var getPdfLauncher: ActivityResultLauncher<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_information_stand)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val buttonBack: Button = findViewById(R.id.button_back)
        buttonBack.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }

        pdfView = findViewById(R.id.pdfView)

        // Регистрация ActivityResultLauncher для выбора PDF файла
        getPdfLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                val file = saveFile(it)
                if (file != null) {
                    displayPdf(file)
                } else {
                    Toast.makeText(this, "Ошибка при загрузке файла", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Автоматически загружаем PDF файл при переходе на этот экран
        loadPdfFromAssets()
    }

//    private fun loadPdf() {
//        getPdfLauncher.launch("application/pdf")
//    }

    private fun loadPdfFromAssets() {
        val assetManager = assets
        val inputStream = assetManager.open("LawsOfChess2023Russian.pdf") // Замените на имя вашего PDF файла
        val file = File(cacheDir, "temp.pdf")

        FileOutputStream(file).use { outputStream ->
            inputStream.copyTo(outputStream)
        }

        displayPdf(file)
    }

    private fun saveFile(uri: Uri): File? {
        val contentResolver = contentResolver
        val inputStream: InputStream? = contentResolver.openInputStream(uri)
        val file = File(cacheDir, "temp.pdf")

        return try {
            val outputStream = FileOutputStream(file)
            inputStream?.copyTo(outputStream)
            outputStream.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } finally {
            inputStream?.close()
        }
    }

    private fun displayPdf(file: File) {
        pdfView.fromFile(file)
            .enableSwipe(true)
            .swipeHorizontal(false)
            .enableDoubletap(true)
            .load()
    }
}
