package com.example.chessio
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path

interface ApiService {
    @GET("api/users")
    suspend fun getUsers(): List<User>
    @POST("api/users")
    fun registerUser (@Body user: User): Call<User>
    @POST("api/login")
    fun enterUser (@Body user: EnterUser): Call<User>
    @GET("api/users/{login}")
    fun getUserByLogin (@Path("login") login: String): Call<User>
    @PUT("api/users")
    fun updateUser (@Body user: User): Call<Void>
    @POST("api/tournaments")
    fun createTournament(@Body tournament: Tournament): Call<Tournament>
    @POST("api/players")
    fun addPlayer(@Body player: Player): Call<Player>
    // Метод для получения всех участников турнира по его ID
    @GET("api/tournaments/{id}/players")
    fun getPlayersByTournamentId(@Path("id") tournamentId: Int): Call<List<Player>>
}