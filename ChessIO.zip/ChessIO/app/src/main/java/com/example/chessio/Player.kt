package com.example.chessio

import com.google.gson.annotations.SerializedName

data class Player(
    @SerializedName("tournament_id") val tournamentId: Int, // Добавлено поле tournament_id
    @SerializedName("name") val name: String,
    @SerializedName("address") val address: String,
    @SerializedName("team") val team: String,
    @SerializedName("points") val points: Float // Изменено с point на points
)
