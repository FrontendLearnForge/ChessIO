package com.example.chessio

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Calendar
import android.text.TextWatcher
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TournamentCreate : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_tournament_create)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val tournamentDate: EditText =findViewById(R.id.date_tournam)
        val tournamentName: EditText =findViewById(R.id.name_tournam)
        val tournamentRefereeName: EditText =findViewById(R.id.name_referee_tournam)
        val tournamentNumberTours: EditText =findViewById(R.id.numbers_tours)
        val tournamentType: Spinner =findViewById(R.id.type_tournam)
        val tournamentFormat: Spinner =findViewById(R.id.format_tournam)


        val tournamentTypes = arrayOf("Личный", "Командный")
        val tournamentFormats = arrayOf("Круговая система", "Швейцарская система", "Система с выбыванием")

        val adapterTypes = ArrayAdapter(this, android.R.layout.simple_spinner_item, tournamentTypes)
        adapterTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        tournamentType.adapter = adapterTypes

        val adapterFormats = ArrayAdapter(this, android.R.layout.simple_spinner_item, tournamentFormats)
        adapterFormats.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        tournamentFormat.adapter = adapterFormats

        val buttonBack: Button =findViewById(R.id.button_back)
        val buttonChooseDate:Button = findViewById(R.id.button_choose_date)
        val buttonCreateTournament: Button =findViewById(R.id.button_create_tournam)

        var type = ""
        var format = ""

        val calendar = Calendar.getInstance()

        tournamentDate.filters = arrayOf(InputFilter.LengthFilter(10))
        tournamentDate.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Форматируем ввод
                if (s != null) {
                    val input =
                        s.toString().replace(Regex("\\D"), "") // Убираем все нечисловые символы
                    val formatted = StringBuilder()

                    for (i in input.indices) {
                        formatted.append(input[i])
                        if (i == 1 || i == 3) {
                            formatted.append(".")
                        }
                    }
                    // Устанавливаем отформатированный текст, если он отличается от оригинального
                    if (formatted.toString() != s.toString()) {
                        tournamentDate.setText(formatted.toString())
                        tournamentDate.setSelection(formatted.length)
                    }
                }
            }
        })

        buttonChooseDate.setOnClickListener {
            val datePickerDialog = DatePickerDialog(this, { _, year, month, day ->
                val date = "$day.${month + 1}.$year"
                tournamentDate.setText(date)
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
            datePickerDialog.show()
        }

        tournamentType.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener { // обработка выбора типа турнира
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: android.view.View,
                    position: Int,
                    id: Long
                ) {
                    type = parent.getItemAtPosition(position).toString()
                    Toast.makeText(
                        this@TournamentCreate,
                        "Выбрано: $type",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onNothingSelected(parent: AdapterView<*>) {}
            }

        tournamentFormat.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {// обработка выбора формата турнира
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: android.view.View,
                position: Int,
                id: Long
            ) {
                format = parent.getItemAtPosition(position).toString()
                Toast.makeText(
                    this@TournamentCreate,
                    "Выбрано: $format",
                    Toast.LENGTH_SHORT
                ).show()
            }

                override fun onNothingSelected(parent: AdapterView<*>) {}
            }

        buttonCreateTournament.setOnClickListener {
            val date = tournamentDate.text.toString().trim()
            val name = tournamentName.text.toString().trim()
            val nameReferee = tournamentRefereeName.text.toString().trim()
            val numberToursText = tournamentNumberTours.text.toString().trim()

            if (date == "" || name == "" || nameReferee == "" || numberToursText == "" || type.isEmpty() || format.isEmpty()) {
                Toast.makeText(this, "Не все поля заполнены", Toast.LENGTH_LONG).show()
            } else {
                val numberTours = if (numberToursText.isNotEmpty()) {
                    try {
                        numberToursText.toInt() // Преобразуем в целое число
                    } catch (e: NumberFormatException) {
                        0 // Значение по умолчанию
                    }
                } else {
                    0 // Значение по умолчанию
                }

                val tournament = Tournament(date=date, name=name, nameReferee=nameReferee, numberTours=numberTours, type=type, format=format)
                Toast.makeText(this, "Турнир $name добавлен", Toast.LENGTH_LONG).show()

                // Отправка данных на сервер
                RetrofitClient.apiService.createTournament(tournament).enqueue(object : Callback<Tournament> {
                    override fun onResponse(call: Call<Tournament>, response: Response<Tournament>) {
                        if (response.isSuccessful) {
                            val createdTournament = response.body() // Получаем созданный турнир
                            val tournamentId = createdTournament?.id // Получаем tournament_id

                            tournamentDate.text.clear()
                            tournamentName.text.clear()
                            tournamentRefereeName.text.clear()
                            tournamentNumberTours.text.clear()
                            tournamentType.setSelection(0)
                            tournamentFormat.setSelection(0)

                            // Переход в AddPlayers при успешном создании турнира
                            val intent = Intent(this@TournamentCreate, AddPlayers::class.java)
                            if (tournamentId != null) {
                                intent.putExtra("TOURNAMENT_ID", tournamentId.toInt())
                            } // Передаем tournament_id
                            startActivity(intent)
                            finish() // Закрыть текущую активность, если это необходимо
                        } else {
                            Toast.makeText(
                                this@TournamentCreate,
                                "Ошибка: ${response.message()}",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }

                    override fun onFailure(call: Call<Tournament>, t: Throwable) {
                        Toast.makeText(this@TournamentCreate, "Ошибка сети: ${t.message}", Toast.LENGTH_LONG).show()
                    }
                })
            }
        }

        buttonBack.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }
    }
}