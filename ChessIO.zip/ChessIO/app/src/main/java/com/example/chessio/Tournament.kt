package com.example.chessio

import com.google.gson.annotations.SerializedName

data class Tournament(
    @SerializedName("id") val id: Int? = null,
    @SerializedName("date") val date: String,
    @SerializedName("name") val name: String,
    @SerializedName("nameReferee") val nameReferee: String,
    @SerializedName("numberTours") val numberTours: Int,
    @SerializedName("type") val type: String,
    @SerializedName("format") val format: String
)