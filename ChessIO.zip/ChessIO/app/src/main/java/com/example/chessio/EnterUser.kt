package com.example.chessio
import com.google.gson.annotations.SerializedName

data class EnterUser (
    @SerializedName("login") val login: String,
    @SerializedName("password") val password: String
)
