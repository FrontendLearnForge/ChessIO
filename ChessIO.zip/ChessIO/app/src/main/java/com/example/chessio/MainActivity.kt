package com.example.chessio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val login: EditText = findViewById(R.id.login)
        val password: EditText = findViewById(R.id.password)
        val buttonEnter: Button = findViewById(R.id.button_enter)
        val buttonRegister: Button = findViewById(R.id.button_register)
        val offlineButton: Button = findViewById(R.id.button_offline)

        buttonRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        offlineButton.setOnClickListener {
            val intent = Intent(this, TournamentCreate::class.java)
            startActivity(intent)
        }

        buttonEnter.setOnClickListener {
            val loginText = login.text.toString().trim()
            val passwordText = password.text.toString().trim()

            if (loginText.isEmpty() || passwordText.isEmpty()) {
                Toast.makeText(this, "Введите логин и пароль", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            // Создание объекта для входа
            val user = EnterUser (loginText, passwordText)

            // Отправка данных на сервер для входа
            RetrofitClient.apiService.enterUser (user).enqueue(object : Callback<User> {
                override fun onResponse(call: Call<User>, response: Response<User>) {
                    if (response.isSuccessful) {
                        // Успешный вход

                        val sharedPreferences = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
                        val editor = sharedPreferences.edit()
                        editor.putString("user_login", user.login) // loggedInUser Login — это логин пользователя
                        editor.apply() // Или editor.commit() для синхронного сохранения

                        Toast.makeText(this@MainActivity, "Вход выполнен", Toast.LENGTH_LONG).show()
                        // переход на главную страницу приложения
                        val intent = Intent(this@MainActivity, MenuActivity::class.java)
                        startActivity(intent)
                        finish() // Закрыть текущую активность
                    } else {
                        // Обработка ошибок
                        when (response.code()) {
                            401 -> Toast.makeText(this@MainActivity, "Неверный логин или пароль", Toast.LENGTH_LONG).show()
                            else -> Toast.makeText(this@MainActivity, "Ошибка: ${response.message()}", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                override fun onFailure(call: Call<User>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Ошибка сети: ${t.message}", Toast.LENGTH_LONG).show()
                }
            })
        }

    }
}