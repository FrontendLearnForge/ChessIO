package com.example.chessio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileActivity : AppCompatActivity() {
    private lateinit var userLogin: EditText
    private lateinit var userName: EditText
    private lateinit var userAddress: EditText
    private lateinit var userPassword: EditText
    private lateinit var userPasswordAgain: EditText
    private lateinit var buttonEdit: Button
    private var isEditing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        userLogin = findViewById(R.id.login_reg)
        userName = findViewById(R.id.name_reg)
        userAddress = findViewById(R.id.adress_reg)
        userPassword = findViewById(R.id.password_reg)
        userPasswordAgain = findViewById(R.id.password_again_reg)

        val buttonBack: Button = findViewById(R.id.button_back)
        buttonBack.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
        }

        buttonEdit = findViewById(R.id.button_edit)
        buttonEdit.setOnClickListener {
            if (isEditing) {
                saveUserData() // Сохраняем данные
            } else {
                toggleEditMode(true) // Включаем режим редактирования
            }
        }

        val sharedPreferences = getSharedPreferences("MyAppPrefs", Context.MODE_PRIVATE)
        val currentLogin = sharedPreferences.getString("user_login", null)

        if (currentLogin != null) {
            loadUserData(currentLogin) // Получите данные из базы данных и заполните поля
        } else {
            Toast.makeText(this, "Пожалуйста, войдите в систему", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadUserData(login: String) {
        RetrofitClient.apiService.getUserByLogin(login).enqueue(object : Callback<User> {
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if (response.isSuccessful) {
                    val user = response.body()
                    if (user != null) {
                        userLogin.setText(user.login)
                        userName.setText(user.username)
                        userAddress.setText(user.address)
                        userPassword.setText(user.password)
                        userPasswordAgain.setText(user.password)
                    } else {
                        Toast.makeText(this@ProfileActivity, "Пользователь не найден", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@ProfileActivity, "Ошибка: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Toast.makeText(this@ProfileActivity, "Ошибка сети: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun toggleEditMode(isEditable: Boolean) {
//        userLogin.isFocusable = isEditable
//        userLogin.isFocusableInTouchMode = isEditable
        userName.isFocusable = isEditable
        userName.isFocusableInTouchMode = isEditable
        userAddress.isFocusable = isEditable
        userAddress.isFocusableInTouchMode = isEditable
        userPassword.isFocusable = isEditable
        userPassword.isFocusableInTouchMode = isEditable
        userPasswordAgain.isFocusable = isEditable
        userPasswordAgain.isFocusableInTouchMode = isEditable

        if (isEditable) {
            buttonEdit.text = "Сохранить"
            isEditing = true
        } else {
            buttonEdit.text = "Редактировать профиль"
            isEditing = false
        }
    }

    private fun saveUserData() {
        val login = userLogin.text.toString().trim()
        val name = userName.text.toString().trim()
        val address = userAddress.text.toString().trim()
        val password = userPassword.text.toString().trim()
        val passwordAgain = userPasswordAgain.text.toString().trim()

        if (login.isEmpty() || name.isEmpty() || address.isEmpty() || password.isEmpty() || passwordAgain.isEmpty()) {
            Toast.makeText(this, "Не все поля заполнены", Toast.LENGTH_LONG).show()
        } else {
            if (password != passwordAgain) {
                Toast.makeText(this, "Введённые пароли не совпадают", Toast.LENGTH_LONG).show()
            } else {
                val updatedUser = User(
                    login = userLogin.text.toString(),
                    username = userName.text.toString(),
                    address = userAddress.text.toString(),
                    password = userPassword.text.toString()
                )

                // Здесь вы должны вызвать метод API для обновления данных пользователя
                RetrofitClient.apiService.updateUser(updatedUser).enqueue(object : Callback<Void> {
                    override fun onResponse(call: Call<Void>, response: Response<Void>) {
                        if (response.isSuccessful) {
                            Toast.makeText(
                                this@ProfileActivity,
                                "Данные успешно обновлены",
                                Toast.LENGTH_SHORT
                            ).show()
                            toggleEditMode(false) // Отключаем режим редактирования
                        } else {
                            Toast.makeText(
                                this@ProfileActivity,
                                "Ошибка: ${response.message()}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onFailure(call: Call<Void>, t: Throwable) {
                        Toast.makeText(
                            this@ProfileActivity,
                            "Ошибка сети: ${t.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                })
            }
        }
    }
}
